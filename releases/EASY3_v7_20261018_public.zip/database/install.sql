-- EASY3 PHP demo; MySQL 8 / MariaDB 10.6+; тестовая отдельная схема.
CREATE DATABASE IF NOT EXISTS system404_easy3 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE system404_easy3;
CREATE TABLE IF NOT EXISTS users (
 id CHAR(32) PRIMARY KEY, email VARCHAR(190) NOT NULL UNIQUE,
 name VARCHAR(100) NOT NULL, password_hash VARCHAR(255) NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS companies (
 id CHAR(32) PRIMARY KEY, name VARCHAR(120) NOT NULL,
 is_demo TINYINT NOT NULL DEFAULT 0, passport LONGTEXT NOT NULL,
 layout LONGTEXT NOT NULL, revision INT NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS memberships (
 user_id CHAR(32) NOT NULL, company_id CHAR(32) NOT NULL,
 role VARCHAR(20) NOT NULL,
 PRIMARY KEY (user_id,company_id),
 FOREIGN KEY (user_id) REFERENCES users(id), FOREIGN KEY (company_id) REFERENCES companies(id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS orders (
 id CHAR(32) PRIMARY KEY, company_id CHAR(32) NOT NULL,
 title VARCHAR(180) NOT NULL, product VARCHAR(180) NOT NULL,
 customer VARCHAR(180) NOT NULL DEFAULT '', mode VARCHAR(12) NOT NULL,
 quantity INT NOT NULL, deadline DATE NOT NULL, start_date DATE NOT NULL,
 price_cents BIGINT NULL, price_basis VARCHAR(12) NOT NULL DEFAULT 'unit',
 target_cents BIGINT NULL, material_owner VARCHAR(12) NOT NULL DEFAULT 'company',
 expenses LONGTEXT NOT NULL, route LONGTEXT NOT NULL, revision INT NOT NULL DEFAULT 1,
 status VARCHAR(20) NOT NULL DEFAULT 'draft', color VARCHAR(20) NOT NULL DEFAULT 'mint',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (company_id) REFERENCES companies(id), INDEX(company_id,status)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS plan_versions (
 id CHAR(32) PRIMARY KEY, company_id CHAR(32) NOT NULL,
 version_no INT NOT NULL, state VARCHAR(20) NOT NULL DEFAULT 'draft',
 snapshot LONGTEXT NOT NULL, input_hash CHAR(64) NOT NULL,
 approvals LONGTEXT NOT NULL, creator_id CHAR(32) NOT NULL,
 published_at DATETIME NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(company_id,version_no), FOREIGN KEY (company_id) REFERENCES companies(id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS tasks (
 id CHAR(32) PRIMARY KEY, company_id CHAR(32) NOT NULL,
 order_id CHAR(32) NOT NULL, plan_id CHAR(32) NOT NULL, operation_id VARCHAR(60) NOT NULL,
 title VARCHAR(180) NOT NULL, resource_id VARCHAR(60) NOT NULL,
 worker_id VARCHAR(60) NOT NULL, quantity INT NOT NULL, released INT NOT NULL DEFAULT 0,
 transferred INT NOT NULL DEFAULT 0, accepted INT NOT NULL DEFAULT 0,
 rework INT NOT NULL DEFAULT 0, rework_ready INT NOT NULL DEFAULT 0, scrap INT NOT NULL DEFAULT 0,
 state VARCHAR(20) NOT NULL DEFAULT 'ready', is_final TINYINT NOT NULL DEFAULT 0,
 dependencies LONGTEXT NOT NULL, revision INT NOT NULL DEFAULT 1,
 planned_start DATETIME NOT NULL, planned_end DATETIME NOT NULL,
 FOREIGN KEY (company_id) REFERENCES companies(id), FOREIGN KEY (order_id) REFERENCES orders(id),
 FOREIGN KEY (plan_id) REFERENCES plan_versions(id), INDEX(company_id,order_id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS production_events (
 id CHAR(32) PRIMARY KEY, company_id CHAR(32) NOT NULL,
 task_id CHAR(32) NOT NULL, actor_id CHAR(32) NOT NULL,
 kind VARCHAR(20) NOT NULL, quantity INT NULL, details LONGTEXT NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (company_id) REFERENCES companies(id), FOREIGN KEY (task_id) REFERENCES tasks(id),
 INDEX(company_id,created_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS audit_log (
 id CHAR(32) PRIMARY KEY, company_id CHAR(32) NOT NULL, actor_id CHAR(32) NOT NULL,
 action VARCHAR(40) NOT NULL, details LONGTEXT NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX(company_id,created_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS idempotency (
 company_id CHAR(32) NOT NULL, actor_id CHAR(32) NOT NULL, command_key VARCHAR(100) NOT NULL,
 request_hash CHAR(64) NOT NULL, response LONGTEXT NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(company_id,actor_id,command_key)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS auth_limits (
 bucket CHAR(64) PRIMARY KEY, failures INT NOT NULL DEFAULT 0,
 window_start DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Обновление уже установленного EASY3: существующие таблицы и факты не меняются.

CREATE TABLE IF NOT EXISTS economy_observations (
 id CHAR(32) PRIMARY KEY, company_id CHAR(32) NOT NULL,
 order_id CHAR(32) NOT NULL, actor_id CHAR(32) NOT NULL,
 revision INT NOT NULL, accepted_quantity INT NOT NULL, recognized_cents BIGINT NULL,
 direct_cents BIGINT NULL, labor_cents BIGINT NULL, common_cents BIGINT NULL,
 source TEXT NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(company_id,order_id,revision),
 FOREIGN KEY (company_id) REFERENCES companies(id),
 FOREIGN KEY (order_id) REFERENCES orders(id),
 FOREIGN KEY (actor_id) REFERENCES users(id),
 CHECK(accepted_quantity>0), CHECK(direct_cents IS NULL OR direct_cents>=0),
 CHECK(labor_cents IS NULL OR labor_cents>=0), CHECK(common_cents IS NULL OR common_cents>=0)
) ENGINE=InnoDB;

-- EASY3 / MySQL 5.7+: run the complete script in the existing database.
-- Existing data, tables and existing foreign keys are not removed or converted.
-- Missing optional columns of older tables are added by app/lib/schema.php.
USE `system404_easy3`;
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `ai_generations` (
 `id` CHAR(32) NOT NULL PRIMARY KEY,
 `company_id` CHAR(32) NOT NULL,
 `actor_id` CHAR(32) NOT NULL,
 `order_id` CHAR(32) NOT NULL,
 `order_revision` INT NOT NULL,
 `request_key` VARCHAR(100) NOT NULL,
 `request_hash` CHAR(64) NOT NULL,
 `state` VARCHAR(20) NOT NULL DEFAULT 'pending',
 `prompt_version` VARCHAR(80) NOT NULL,
 `model` VARCHAR(80) NULL,
 `response_json` LONGTEXT NULL,
 `usage_json` LONGTEXT NULL,
 `latency_ms` INT NULL,
 `error_code` VARCHAR(40) NULL,
 `request_json` LONGTEXT NULL,
 `job_json` LONGTEXT NULL,
 `lease_token` CHAR(32) NULL,
 `lease_until` DATETIME NULL,
 `call_count` INT NOT NULL DEFAULT 0,
 `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY `ai_command` (`company_id`,`actor_id`,`request_key`),
 KEY `ai_company_day` (`company_id`,`created_at`),
 KEY `ai_actor_order` (`actor_id`,`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- EASY3: полностью вымышленные тестовые данные.
-- Даты учебного плана соответствуют моменту сборки; свежий план создаётся кнопкой «Открыть демо».
USE system404_easy3;
INSERT IGNORE INTO users (id,email,name,password_hash) VALUES ('3c08116887717e147b163f3c85c9f731','owner@demo.easy3.local','Собственник','$2y$10$YG6/mdt.MWISNi66iRFPGOzyRoG0HdAyCREQa4hgwOnZZNLA3EnGq');
INSERT IGNORE INTO users (id,email,name,password_hash) VALUES ('63d1f97bcb56173e442db465604005ea','foreman@demo.easy3.local','Мастер','$2y$10$YG6/mdt.MWISNi66iRFPGOzyRoG0HdAyCREQa4hgwOnZZNLA3EnGq');
INSERT IGNORE INTO users (id,email,name,password_hash) VALUES ('f6f29539e151a721dd30a8b79d7b4722','technologist@demo.easy3.local','Технолог','$2y$10$YG6/mdt.MWISNi66iRFPGOzyRoG0HdAyCREQa4hgwOnZZNLA3EnGq');
INSERT IGNORE INTO users (id,email,name,password_hash) VALUES ('7238c4aa453d5df837cc321a89b29aea','chief@demo.easy3.local','Начальник производства','$2y$10$YG6/mdt.MWISNi66iRFPGOzyRoG0HdAyCREQa4hgwOnZZNLA3EnGq');
INSERT IGNORE INTO users (id,email,name,password_hash) VALUES ('6b3bcd816f44719a2ccb44ea91dbff7a','worker@demo.easy3.local','Швея 01','$2y$10$YG6/mdt.MWISNi66iRFPGOzyRoG0HdAyCREQa4hgwOnZZNLA3EnGq');
INSERT IGNORE INTO users (id,email,name,password_hash) VALUES ('553af941afec306886f84c8588a79ba4','qc@demo.easy3.local','Контролёр ОТК','$2y$10$YG6/mdt.MWISNi66iRFPGOzyRoG0HdAyCREQa4hgwOnZZNLA3EnGq');
INSERT IGNORE INTO companies (id,name,is_demo,passport,layout,revision) VALUES ('51d1b4be40ad979966a96944d51171fc','Ателье Север',1,'{"industry":"Швейное производство","city":"Санкт-Петербург","area":216,"timezone":"Europe/Moscow","description":"Небольшая фабрика трикотажных изделий. Тестовые данные EASY3.","structure":{"workshops":[{"id":"w-main","name":"Швейный цех"}],"brigades":[{"id":"b-sew","name":"Бригада пошива","workshop":"w-main","lead":"p-foreman"}]},"people":[{"id":"p-chief","name":"Начальник производства","role":"Начальник производства","roles":["chief"],"workshop":"w-main","brigade":"","skills":[],"active":true},{"id":"p-tech","name":"Технолог","role":"Технолог","roles":["technologist"],"workshop":"w-main","brigade":"","skills":[],"active":true},{"id":"p-foreman","name":"Бригадир","role":"Бригадир","roles":["foreman"],"workshop":"w-main","brigade":"b-sew","skills":[],"active":true},{"id":"p-cut","name":"Раскройщик 01","role":"Раскройщик","skills":["cut"],"active":true,"roles":["worker"],"workshop":"w-main","brigade":""},{"id":"p-sew-1","roles":["worker"],"workshop":"w-main","brigade":"b-sew","name":"Швея 01","role":"Швея","skills":["sew","overlock"],"active":true},{"id":"p-sew-2","roles":["worker"],"workshop":"w-main","brigade":"b-sew","name":"Швея 02","role":"Швея","skills":["sew","overlock"],"active":true},{"id":"p-sew-3","roles":["worker"],"workshop":"w-main","brigade":"b-sew","name":"Швея 03","role":"Швея","skills":["sew","overlock"],"active":true},{"id":"p-iron","name":"Оператор ВТО","role":"ВТО","skills":["iron"],"active":true,"roles":["worker"],"workshop":"w-main","brigade":""},{"id":"p-qc","name":"Контролёр ОТК","role":"ОТК","skills":["qc","pack"],"active":true,"roles":["worker"],"workshop":"w-main","brigade":""}],"shift":{"start":"09:00","end":"18:00","break_start":"13:00","break_minutes":60,"days":[1,2,3,4,5]},"resources":[{"id":"cut-1","name":"Раскройный стол","type":"cut","worker":"p-cut","active":true,"workshop":"w-main"},{"id":"sew-1","name":"Прямострочная 01","type":"sew","worker":"p-sew-1","active":true,"workshop":"w-main"},{"id":"sew-2","name":"Прямострочная 02","type":"sew","worker":"p-sew-2","active":true,"workshop":"w-main"},{"id":"over-1","name":"Оверлок 01","type":"overlock","worker":"p-sew-3","active":true,"workshop":"w-main"},{"id":"iron-1","name":"Стол ВТО","type":"iron","worker":"p-iron","active":true,"workshop":"w-main"},{"id":"qc-1","name":"Стол ОТК","type":"qc","worker":"p-qc","active":true,"workshop":"w-main"},{"id":"pack-1","name":"Упаковка","type":"pack","worker":"p-qc","active":true,"workshop":"w-main"}],"economy":{"labor_hour_cents":45000,"monthly_common_cents":28500000,"monthly_hours":960,"excluded":["Продажи бренда","Налоги компании","Кредитные платежи","Непроизводственная администрация"],"unknown":["Расходы на обслуживание оборудования"],"currency":"RUB"}}','{"width":18,"depth":12,"objects":[{"id":"f-cut","resource":"cut-1","type":"cut","x":-5.5,"z":-2.7,"rotation":0,"zone":"Раскрой"},{"id":"f-s1","resource":"sew-1","type":"sew","x":-1.6,"z":-2.7,"rotation":0,"zone":"Пошив"},{"id":"f-s2","resource":"sew-2","type":"sew","x":1.5,"z":-2.7,"rotation":0,"zone":"Пошив"},{"id":"f-o1","resource":"over-1","type":"overlock","x":4.8,"z":-2.7,"rotation":0,"zone":"Пошив"},{"id":"f-iron","resource":"iron-1","type":"iron","x":4.8,"z":1.7,"rotation":0,"zone":"Финиш"},{"id":"f-qc","resource":"qc-1","type":"qc","x":1.4,"z":1.7,"rotation":0,"zone":"Финиш"},{"id":"f-pack","resource":"pack-1","type":"pack","x":-1.9,"z":1.7,"rotation":0,"zone":"Финиш"},{"id":"f-stock","resource":"","type":"storage","x":-6,"z":2.2,"rotation":0,"zone":"Склад"}],"links":[["f-cut","f-s1"],["f-s1","f-o1"],["f-o1","f-iron"],["f-iron","f-qc"],["f-qc","f-pack"]]}',1);
INSERT IGNORE INTO memberships (user_id,company_id,role) VALUES ('3c08116887717e147b163f3c85c9f731','51d1b4be40ad979966a96944d51171fc','owner');
INSERT IGNORE INTO memberships (user_id,company_id,role) VALUES ('63d1f97bcb56173e442db465604005ea','51d1b4be40ad979966a96944d51171fc','foreman');
INSERT IGNORE INTO memberships (user_id,company_id,role) VALUES ('f6f29539e151a721dd30a8b79d7b4722','51d1b4be40ad979966a96944d51171fc','technologist');
INSERT IGNORE INTO memberships (user_id,company_id,role) VALUES ('7238c4aa453d5df837cc321a89b29aea','51d1b4be40ad979966a96944d51171fc','chief');
INSERT IGNORE INTO memberships (user_id,company_id,role) VALUES ('6b3bcd816f44719a2ccb44ea91dbff7a','51d1b4be40ad979966a96944d51171fc','worker');
INSERT IGNORE INTO memberships (user_id,company_id,role) VALUES ('553af941afec306886f84c8588a79ba4','51d1b4be40ad979966a96944d51171fc','qc');
INSERT IGNORE INTO orders (id,company_id,title,product,customer,mode,quantity,price_cents,target_cents,deadline,start_date,price_basis,material_owner,expenses,route,revision,color,status) VALUES ('cdae4918579dc32ceed5a0d9e91a6731','51d1b4be40ad979966a96944d51171fc','Худи «Север»','Худи из футера','Заказчик 01','CONTRACT',600,125000,NULL,'2026-10-25','2026-10-11','unit','customer','[{"id":"e-1","name":"Лекала и подготовка","kind":"direct","cents":1800000},{"id":"e-2","name":"Логистика","kind":"direct","cents":650000}]','[{"id":"op-1","name":"Раскрой деталей","type":"cut","seconds":120,"setup_minutes":12,"dependencies":[],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-2","name":"Сборка изделия","type":"sew","seconds":240,"setup_minutes":5,"dependencies":["op-1"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-3","name":"Обработка швов","type":"overlock","seconds":150,"setup_minutes":5,"dependencies":["op-2"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-4","name":"Влажно-тепловая обработка","type":"iron","seconds":55,"setup_minutes":5,"dependencies":["op-3"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-5","name":"Контроль качества","type":"qc","seconds":35,"setup_minutes":5,"dependencies":["op-4"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-6","name":"Упаковка","type":"pack","seconds":25,"setup_minutes":5,"dependencies":["op-5"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50}]',1,'mint','active');
INSERT IGNORE INTO orders (id,company_id,title,product,customer,mode,quantity,price_cents,target_cents,deadline,start_date,price_basis,material_owner,expenses,route,revision,color,status) VALUES ('bdef42ac69876c643e4c323813440afc','51d1b4be40ad979966a96944d51171fc','Футболка «Линия»','Футболка базовая','Внутренний заказ','OWN',350,NULL,56000,'2026-10-21','2026-10-11','unit','company','[{"id":"e-1","name":"Лекала и подготовка","kind":"direct","cents":1800000},{"id":"e-2","name":"Логистика","kind":"direct","cents":650000},{"id":"e-3","name":"Материал для партии","kind":"direct","cents":4200000}]','[{"id":"op-1","name":"Раскрой деталей","type":"cut","seconds":65,"setup_minutes":12,"dependencies":[],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-2","name":"Сборка изделия","type":"sew","seconds":105,"setup_minutes":5,"dependencies":["op-1"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-3","name":"Обработка швов","type":"overlock","seconds":70,"setup_minutes":5,"dependencies":["op-2"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-4","name":"Влажно-тепловая обработка","type":"iron","seconds":35,"setup_minutes":5,"dependencies":["op-3"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-5","name":"Контроль качества","type":"qc","seconds":25,"setup_minutes":5,"dependencies":["op-4"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-6","name":"Упаковка","type":"pack","seconds":20,"setup_minutes":5,"dependencies":["op-5"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50}]',1,'gold','active');
INSERT IGNORE INTO orders (id,company_id,title,product,customer,mode,quantity,price_cents,target_cents,deadline,start_date,price_basis,material_owner,expenses,route,revision,color,status) VALUES ('42ac4a2ef838b9ad0043123b3c29d80a','51d1b4be40ad979966a96944d51171fc','Свитшот «Туман»','Свитшот без капюшона','Заказчик 03','CONTRACT',280,145000,NULL,'2026-10-29','2026-10-11','unit','customer','[{"id":"e-1","name":"Лекала и подготовка","kind":"direct","cents":1800000},{"id":"e-2","name":"Логистика","kind":"direct","cents":650000}]','[{"id":"op-1","name":"Раскрой деталей","type":"cut","seconds":120,"setup_minutes":12,"dependencies":[],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-2","name":"Сборка изделия","type":"sew","seconds":240,"setup_minutes":5,"dependencies":["op-1"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-3","name":"Обработка швов","type":"overlock","seconds":150,"setup_minutes":5,"dependencies":["op-2"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-4","name":"Влажно-тепловая обработка","type":"iron","seconds":55,"setup_minutes":5,"dependencies":["op-3"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-5","name":"Контроль качества","type":"qc","seconds":35,"setup_minutes":5,"dependencies":["op-4"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-6","name":"Упаковка","type":"pack","seconds":25,"setup_minutes":5,"dependencies":["op-5"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50}]',1,'clay','active');
INSERT IGNORE INTO plan_versions (id,company_id,version_no,state,snapshot,input_hash,approvals,creator_id,published_at) VALUES ('529c13acdaad61005954d82f434d58e9','51d1b4be40ad979966a96944d51171fc',1,'published','{"engine":"easy3-calendar-list/1.0","status":"feasible","errors":[],"warnings":["Худи «Север»: прогноз позже коммерческого срока"],"schedule":[{"order_id":"bdef42ac69876c643e4c323813440afc","operation_id":"op-1","title":"Раскрой деталей","resource_id":"cut-1","worker_id":"p-cut","quantity":350,"start":"2026-10-12 09:00:00","end":"2026-10-12 16:31:10","slots":[["2026-10-12 09:00:00","2026-10-12 13:00:00"],["2026-10-12 14:00:00","2026-10-12 16:31:10"]],"seconds":23470,"dependencies":[],"is_final":false,"pinned":false},{"order_id":"bdef42ac69876c643e4c323813440afc","operation_id":"op-2","title":"Сборка изделия","resource_id":"sew-1","worker_id":"p-sew-1","quantity":350,"start":"2026-10-12 16:31:10","end":"2026-10-14 09:48:40","slots":[["2026-10-12 16:31:10","2026-10-12 18:00:00"],["2026-10-13 09:00:00","2026-10-13 13:00:00"],["2026-10-13 14:00:00","2026-10-13 18:00:00"],["2026-10-14 09:00:00","2026-10-14 09:48:40"]],"seconds":37050,"dependencies":["op-1"],"is_final":false,"pinned":false},{"order_id":"bdef42ac69876c643e4c323813440afc","operation_id":"op-3","title":"Обработка швов","resource_id":"over-1","worker_id":"p-sew-3","quantity":350,"start":"2026-10-14 09:48:40","end":"2026-10-14 17:42:00","slots":[["2026-10-14 09:48:40","2026-10-14 13:00:00"],["2026-10-14 14:00:00","2026-10-14 17:42:00"]],"seconds":24800,"dependencies":["op-2"],"is_final":false,"pinned":false},{"order_id":"bdef42ac69876c643e4c323813440afc","operation_id":"op-4","title":"Влажно-тепловая обработка","resource_id":"iron-1","worker_id":"p-iron","quantity":350,"start":"2026-10-14 17:42:00","end":"2026-10-15 12:11:10","slots":[["2026-10-14 17:42:00","2026-10-14 18:00:00"],["2026-10-15 09:00:00","2026-10-15 12:11:10"]],"seconds":12550,"dependencies":["op-3"],"is_final":false,"pinned":false},{"order_id":"bdef42ac69876c643e4c323813440afc","operation_id":"op-5","title":"Контроль качества","resource_id":"qc-1","worker_id":"p-qc","quantity":350,"start":"2026-10-15 12:11:10","end":"2026-10-15 15:42:00","slots":[["2026-10-15 12:11:10","2026-10-15 13:00:00"],["2026-10-15 14:00:00","2026-10-15 15:42:00"]],"seconds":9050,"dependencies":["op-4"],"is_final":false,"pinned":false},{"order_id":"bdef42ac69876c643e4c323813440afc","operation_id":"op-6","title":"Упаковка","resource_id":"pack-1","worker_id":"p-qc","quantity":350,"start":"2026-10-15 15:42:00","end":"2026-10-15 17:43:40","slots":[["2026-10-15 15:42:00","2026-10-15 17:43:40"]],"seconds":7300,"dependencies":["op-5"],"is_final":true,"pinned":false},{"order_id":"cdae4918579dc32ceed5a0d9e91a6731","operation_id":"op-1","title":"Раскрой деталей","resource_id":"cut-1","worker_id":"p-cut","quantity":600,"start":"2026-10-12 16:31:10","end":"2026-10-15 11:43:10","slots":[["2026-10-12 16:31:10","2026-10-12 18:00:00"],["2026-10-13 09:00:00","2026-10-13 13:00:00"],["2026-10-13 14:00:00","2026-10-13 18:00:00"],["2026-10-14 09:00:00","2026-10-14 13:00:00"],["2026-10-14 14:00:00","2026-10-14 18:00:00"],["2026-10-15 09:00:00","2026-10-15 11:43:10"]],"seconds":72720,"dependencies":[],"is_final":false,"pinned":false},{"order_id":"cdae4918579dc32ceed5a0d9e91a6731","operation_id":"op-2","title":"Сборка изделия","resource_id":"sew-1","worker_id":"p-sew-1","quantity":600,"start":"2026-10-15 11:43:10","end":"2026-10-22 11:48:10","slots":[["2026-10-15 11:43:10","2026-10-15 13:00:00"],["2026-10-15 14:00:00","2026-10-15 18:00:00"],["2026-10-16 09:00:00","2026-10-16 13:00:00"],["2026-10-16 14:00:00","2026-10-16 18:00:00"],["2026-10-19 09:00:00","2026-10-19 13:00:00"],["2026-10-19 14:00:00","2026-10-19 18:00:00"],["2026-10-20 09:00:00","2026-10-20 13:00:00"],["2026-10-20 14:00:00","2026-10-20 18:00:00"],["2026-10-21 09:00:00","2026-10-21 13:00:00"],["2026-10-21 14:00:00","2026-10-21 18:00:00"],["2026-10-22 09:00:00","2026-10-22 11:48:10"]],"seconds":144300,"dependencies":["op-1"],"is_final":false,"pinned":false},{"order_id":"cdae4918579dc32ceed5a0d9e91a6731","operation_id":"op-3","title":"Обработка швов","resource_id":"over-1","worker_id":"p-sew-3","quantity":600,"start":"2026-10-22 11:48:10","end":"2026-10-27 12:53:10","slots":[["2026-10-22 11:48:10","2026-10-22 13:00:00"],["2026-10-22 14:00:00","2026-10-22 18:00:00"],["2026-10-23 09:00:00","2026-10-23 13:00:00"],["2026-10-23 14:00:00","2026-10-23 18:00:00"],["2026-10-26 09:00:00","2026-10-26 13:00:00"],["2026-10-26 14:00:00","2026-10-26 18:00:00"],["2026-10-27 09:00:00","2026-10-27 12:53:10"]],"seconds":90300,"dependencies":["op-2"],"is_final":false,"pinned":false},{"order_id":"cdae4918579dc32ceed5a0d9e91a6731","operation_id":"op-4","title":"Влажно-тепловая обработка","resource_id":"iron-1","worker_id":"p-iron","quantity":600,"start":"2026-10-27 12:53:10","end":"2026-10-28 15:08:10","slots":[["2026-10-27 12:53:10","2026-10-27 13:00:00"],["2026-10-27 14:00:00","2026-10-27 18:00:00"],["2026-10-28 09:00:00","2026-10-28 13:00:00"],["2026-10-28 14:00:00","2026-10-28 15:08:10"]],"seconds":33300,"dependencies":["op-3"],"is_final":false,"pinned":false},{"order_id":"cdae4918579dc32ceed5a0d9e91a6731","operation_id":"op-5","title":"Контроль качества","resource_id":"qc-1","worker_id":"p-qc","quantity":600,"start":"2026-10-28 15:08:10","end":"2026-10-29 12:03:10","slots":[["2026-10-28 15:08:10","2026-10-28 18:00:00"],["2026-10-29 09:00:00","2026-10-29 12:03:10"]],"seconds":21300,"dependencies":["op-4"],"is_final":false,"pinned":false},{"order_id":"cdae4918579dc32ceed5a0d9e91a6731","operation_id":"op-6","title":"Упаковка","resource_id":"pack-1","worker_id":"p-qc","quantity":600,"start":"2026-10-29 12:03:10","end":"2026-10-29 17:18:10","slots":[["2026-10-29 12:03:10","2026-10-29 13:00:00"],["2026-10-29 14:00:00","2026-10-29 17:18:10"]],"seconds":15300,"dependencies":["op-5"],"is_final":true,"pinned":false},{"order_id":"42ac4a2ef838b9ad0043123b3c29d80a","operation_id":"op-1","title":"Раскрой деталей","resource_id":"cut-1","worker_id":"p-cut","quantity":280,"start":"2026-10-15 11:43:10","end":"2026-10-16 14:15:10","slots":[["2026-10-15 11:43:10","2026-10-15 13:00:00"],["2026-10-15 14:00:00","2026-10-15 18:00:00"],["2026-10-16 09:00:00","2026-10-16 13:00:00"],["2026-10-16 14:00:00","2026-10-16 14:15:10"]],"seconds":34320,"dependencies":[],"is_final":false,"pinned":false},{"order_id":"42ac4a2ef838b9ad0043123b3c29d80a","operation_id":"op-2","title":"Сборка изделия","resource_id":"sew-2","worker_id":"p-sew-2","quantity":280,"start":"2026-10-16 14:15:10","end":"2026-10-20 17:00:10","slots":[["2026-10-16 14:15:10","2026-10-16 18:00:00"],["2026-10-19 09:00:00","2026-10-19 13:00:00"],["2026-10-19 14:00:00","2026-10-19 18:00:00"],["2026-10-20 09:00:00","2026-10-20 13:00:00"],["2026-10-20 14:00:00","2026-10-20 17:00:10"]],"seconds":67500,"dependencies":["op-1"],"is_final":false,"pinned":false},{"order_id":"42ac4a2ef838b9ad0043123b3c29d80a","operation_id":"op-3","title":"Обработка швов","resource_id":"over-1","worker_id":"p-sew-3","quantity":280,"start":"2026-10-20 17:00:10","end":"2026-10-22 11:45:10","slots":[["2026-10-20 17:00:10","2026-10-20 18:00:00"],["2026-10-21 09:00:00","2026-10-21 13:00:00"],["2026-10-21 14:00:00","2026-10-21 18:00:00"],["2026-10-22 09:00:00","2026-10-22 11:45:10"]],"seconds":42300,"dependencies":["op-2"],"is_final":false,"pinned":false},{"order_id":"42ac4a2ef838b9ad0043123b3c29d80a","operation_id":"op-4","title":"Влажно-тепловая обработка","resource_id":"iron-1","worker_id":"p-iron","quantity":280,"start":"2026-10-22 11:45:10","end":"2026-10-22 17:06:50","slots":[["2026-10-22 11:45:10","2026-10-22 13:00:00"],["2026-10-22 14:00:00","2026-10-22 17:06:50"]],"seconds":15700,"dependencies":["op-3"],"is_final":false,"pinned":false},{"order_id":"42ac4a2ef838b9ad0043123b3c29d80a","operation_id":"op-5","title":"Контроль качества","resource_id":"qc-1","worker_id":"p-qc","quantity":280,"start":"2026-10-22 17:06:50","end":"2026-10-23 10:55:10","slots":[["2026-10-22 17:06:50","2026-10-22 18:00:00"],["2026-10-23 09:00:00","2026-10-23 10:55:10"]],"seconds":10100,"dependencies":["op-4"],"is_final":false,"pinned":false},{"order_id":"42ac4a2ef838b9ad0043123b3c29d80a","operation_id":"op-6","title":"Упаковка","resource_id":"pack-1","worker_id":"p-qc","quantity":280,"start":"2026-10-23 10:55:10","end":"2026-10-23 12:56:50","slots":[["2026-10-23 10:55:10","2026-10-23 12:56:50"]],"seconds":7300,"dependencies":["op-5"],"is_final":true,"pinned":false}],"strategy":"deadline","calculated_at":"2026-10-11T12:17:02+03:00","timezone":"Europe/Moscow","order_finishes":{"bdef42ac69876c643e4c323813440afc":"2026-10-15 17:43:40","cdae4918579dc32ceed5a0d9e91a6731":"2026-10-29 17:18:10","42ac4a2ef838b9ad0043123b3c29d80a":"2026-10-23 12:56:50"},"late_orders":1,"finish":"2026-10-29 17:18:10","economy":{"bdef42ac69876c643e4c323813440afc":{"norm_seconds":114220,"scope":"Производственный контур","status":"partial","cost_cents":9019668,"labor_cents":1427750,"common_cents":941918,"direct_cents":6650000,"unit_cents":25770,"value_cents":null,"result_cents":null,"unknown":["Расходы на обслуживание оборудования"],"excluded":["Продажи бренда","Налоги компании","Кредитные платежи","Непроизводственная администрация"],"method":"Прямые статьи + нормированный труд + доля общих расходов по трудочасам"},"cdae4918579dc32ceed5a0d9e91a6731":{"norm_seconds":377220,"scope":"Производственный контур","status":"partial","cost_cents":10276005,"labor_cents":4715250,"common_cents":3110755,"direct_cents":2450000,"unit_cents":17127,"value_cents":75000000,"result_cents":64723995,"unknown":["Расходы на обслуживание оборудования"],"excluded":["Продажи бренда","Налоги компании","Кредитные платежи","Непроизводственная администрация"],"method":"Прямые статьи + нормированный труд + доля общих расходов по трудочасам"},"42ac4a2ef838b9ad0043123b3c29d80a":{"norm_seconds":177220,"scope":"Производственный контур","status":"partial","cost_cents":6126700,"labor_cents":2215250,"common_cents":1461450,"direct_cents":2450000,"unit_cents":21881,"value_cents":40600000,"result_cents":34473300,"unknown":["Расходы на обслуживание оборудования"],"excluded":["Продажи бренда","Налоги компании","Кредитные платежи","Непроизводственная администрация"],"method":"Прямые статьи + нормированный труд + доля общих расходов по трудочасам"}},"layout":{"width":18,"depth":12,"objects":[{"id":"f-cut","resource":"cut-1","type":"cut","x":-5.5,"z":-2.7,"rotation":0,"zone":"Раскрой"},{"id":"f-s1","resource":"sew-1","type":"sew","x":-1.6,"z":-2.7,"rotation":0,"zone":"Пошив"},{"id":"f-s2","resource":"sew-2","type":"sew","x":1.5,"z":-2.7,"rotation":0,"zone":"Пошив"},{"id":"f-o1","resource":"over-1","type":"overlock","x":4.8,"z":-2.7,"rotation":0,"zone":"Пошив"},{"id":"f-iron","resource":"iron-1","type":"iron","x":4.8,"z":1.7,"rotation":0,"zone":"Финиш"},{"id":"f-qc","resource":"qc-1","type":"qc","x":1.4,"z":1.7,"rotation":0,"zone":"Финиш"},{"id":"f-pack","resource":"pack-1","type":"pack","x":-1.9,"z":1.7,"rotation":0,"zone":"Финиш"},{"id":"f-stock","resource":"","type":"storage","x":-6,"z":2.2,"rotation":0,"zone":"Склад"}],"links":[["f-cut","f-s1"],["f-s1","f-o1"],["f-o1","f-iron"],["f-iron","f-qc"],["f-qc","f-pack"]]},"resource_snapshot":[{"id":"cut-1","name":"Раскройный стол","type":"cut","worker":"p-cut","active":true,"workshop":"w-main"},{"id":"sew-1","name":"Прямострочная 01","type":"sew","worker":"p-sew-1","active":true,"workshop":"w-main"},{"id":"sew-2","name":"Прямострочная 02","type":"sew","worker":"p-sew-2","active":true,"workshop":"w-main"},{"id":"over-1","name":"Оверлок 01","type":"overlock","worker":"p-sew-3","active":true,"workshop":"w-main"},{"id":"iron-1","name":"Стол ВТО","type":"iron","worker":"p-iron","active":true,"workshop":"w-main"},{"id":"qc-1","name":"Стол ОТК","type":"qc","worker":"p-qc","active":true,"workshop":"w-main"},{"id":"pack-1","name":"Упаковка","type":"pack","worker":"p-qc","active":true,"workshop":"w-main"}],"structure_snapshot":{"workshops":[{"id":"w-main","name":"Швейный цех"}],"brigades":[{"id":"b-sew","name":"Бригада пошива","workshop":"w-main","lead":"p-foreman"}]},"people_snapshot":[{"id":"p-chief","name":"Начальник производства","role":"Начальник производства","roles":["chief"],"workshop":"w-main","brigade":"","skills":[],"active":true},{"id":"p-tech","name":"Технолог","role":"Технолог","roles":["technologist"],"workshop":"w-main","brigade":"","skills":[],"active":true},{"id":"p-foreman","name":"Бригадир","role":"Бригадир","roles":["foreman"],"workshop":"w-main","brigade":"b-sew","skills":[],"active":true},{"id":"p-cut","name":"Раскройщик 01","role":"Раскройщик","skills":["cut"],"active":true,"roles":["worker"],"workshop":"w-main","brigade":""},{"id":"p-sew-1","roles":["worker"],"workshop":"w-main","brigade":"b-sew","name":"Швея 01","role":"Швея","skills":["sew","overlock"],"active":true},{"id":"p-sew-2","roles":["worker"],"workshop":"w-main","brigade":"b-sew","name":"Швея 02","role":"Швея","skills":["sew","overlock"],"active":true},{"id":"p-sew-3","roles":["worker"],"workshop":"w-main","brigade":"b-sew","name":"Швея 03","role":"Швея","skills":["sew","overlock"],"active":true},{"id":"p-iron","name":"Оператор ВТО","role":"ВТО","skills":["iron"],"active":true,"roles":["worker"],"workshop":"w-main","brigade":""},{"id":"p-qc","name":"Контролёр ОТК","role":"ОТК","skills":["qc","pack"],"active":true,"roles":["worker"],"workshop":"w-main","brigade":""}],"shift_snapshot":{"start":"09:00","end":"18:00","break_start":"13:00","break_minutes":60,"days":[1,2,3,4,5]},"order_revisions":{"bdef42ac69876c643e4c323813440afc":1,"cdae4918579dc32ceed5a0d9e91a6731":1,"42ac4a2ef838b9ad0043123b3c29d80a":1},"routes":{"bdef42ac69876c643e4c323813440afc":[{"id":"op-1","name":"Раскрой деталей","type":"cut","seconds":65,"setup_minutes":12,"dependencies":[],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-2","name":"Сборка изделия","type":"sew","seconds":105,"setup_minutes":5,"dependencies":["op-1"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-3","name":"Обработка швов","type":"overlock","seconds":70,"setup_minutes":5,"dependencies":["op-2"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-4","name":"Влажно-тепловая обработка","type":"iron","seconds":35,"setup_minutes":5,"dependencies":["op-3"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-5","name":"Контроль качества","type":"qc","seconds":25,"setup_minutes":5,"dependencies":["op-4"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-6","name":"Упаковка","type":"pack","seconds":20,"setup_minutes":5,"dependencies":["op-5"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50}],"cdae4918579dc32ceed5a0d9e91a6731":[{"id":"op-1","name":"Раскрой деталей","type":"cut","seconds":120,"setup_minutes":12,"dependencies":[],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-2","name":"Сборка изделия","type":"sew","seconds":240,"setup_minutes":5,"dependencies":["op-1"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-3","name":"Обработка швов","type":"overlock","seconds":150,"setup_minutes":5,"dependencies":["op-2"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-4","name":"Влажно-тепловая обработка","type":"iron","seconds":55,"setup_minutes":5,"dependencies":["op-3"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-5","name":"Контроль качества","type":"qc","seconds":35,"setup_minutes":5,"dependencies":["op-4"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-6","name":"Упаковка","type":"pack","seconds":25,"setup_minutes":5,"dependencies":["op-5"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50}],"42ac4a2ef838b9ad0043123b3c29d80a":[{"id":"op-1","name":"Раскрой деталей","type":"cut","seconds":120,"setup_minutes":12,"dependencies":[],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-2","name":"Сборка изделия","type":"sew","seconds":240,"setup_minutes":5,"dependencies":["op-1"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-3","name":"Обработка швов","type":"overlock","seconds":150,"setup_minutes":5,"dependencies":["op-2"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-4","name":"Влажно-тепловая обработка","type":"iron","seconds":55,"setup_minutes":5,"dependencies":["op-3"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-5","name":"Контроль качества","type":"qc","seconds":35,"setup_minutes":5,"dependencies":["op-4"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50},{"id":"op-6","name":"Упаковка","type":"pack","seconds":25,"setup_minutes":5,"dependencies":["op-5"],"source":"Учебная норма демо v1; не норматив предприятия","batch":50}]},"assumptions":["Учебные нормы, указанные в операциях","Эвристика списка работ; оптимальность не доказана","Операция планируется целым объёмом с разрывом на смены","Параллельные ветви допустимы; количественные коэффициенты узлов 1:1","Материалы предполагаются готовыми; склад и поступления не моделируются","Начатые задания сохраняют факты и назначения. Просроченный начатый интервал получает допущение +1 час"],"input_hash":"6c24cb8ee9ea0e1ccd4974296091e7b21de8649e438ec752130ea9896b3e2324","company_revision":1,"source_event_count":0}','6c24cb8ee9ea0e1ccd4974296091e7b21de8649e438ec752130ea9896b3e2324','[{"stage":"foreman","actor_id":"3c08116887717e147b163f3c85c9f731","at":"2026-10-11T04:37:38+03:00","input_hash":"6c24cb8ee9ea0e1ccd4974296091e7b21de8649e438ec752130ea9896b3e2324","source":"Учебный план"},{"stage":"technologist","actor_id":"3c08116887717e147b163f3c85c9f731","at":"2026-10-11T04:37:38+03:00","input_hash":"6c24cb8ee9ea0e1ccd4974296091e7b21de8649e438ec752130ea9896b3e2324","source":"Учебный план"},{"stage":"chief","actor_id":"3c08116887717e147b163f3c85c9f731","at":"2026-10-11T04:37:38+03:00","input_hash":"6c24cb8ee9ea0e1ccd4974296091e7b21de8649e438ec752130ea9896b3e2324","source":"Учебный план"}]','3c08116887717e147b163f3c85c9f731','2026-10-11 04:37:38');
INSERT IGNORE INTO tasks (id,company_id,order_id,plan_id,operation_id,title,resource_id,worker_id,quantity,released,transferred,accepted,rework,rework_ready,scrap,state,is_final,dependencies,revision,planned_start,planned_end) VALUES ('e90e24bd51e36203d251fd7d480d528a','51d1b4be40ad979966a96944d51171fc','bdef42ac69876c643e4c323813440afc','529c13acdaad61005954d82f434d58e9','op-1','Раскрой деталей','cut-1','p-cut',350,0,0,0,0,0,0,'ready',0,'[]',1,'2026-10-12 09:00:00','2026-10-12 16:31:10');
INSERT IGNORE INTO tasks (id,company_id,order_id,plan_id,operation_id,title,resource_id,worker_id,quantity,released,transferred,accepted,rework,rework_ready,scrap,state,is_final,dependencies,revision,planned_start,planned_end) VALUES ('f3585367a91f6d091ae990baf9d16440','51d1b4be40ad979966a96944d51171fc','bdef42ac69876c643e4c323813440afc','529c13acdaad61005954d82f434d58e9','op-2','Сборка изделия','sew-1','p-sew-1',350,0,0,0,0,0,0,'ready',0,'["e90e24bd51e36203d251fd7d480d528a"]',1,'2026-10-12 16:31:10','2026-10-14 09:48:40');
INSERT IGNORE INTO tasks (id,company_id,order_id,plan_id,operation_id,title,resource_id,worker_id,quantity,released,transferred,accepted,rework,rework_ready,scrap,state,is_final,dependencies,revision,planned_start,planned_end) VALUES ('4ad9227e7c967701205f12e4c908f990','51d1b4be40ad979966a96944d51171fc','bdef42ac69876c643e4c323813440afc','529c13acdaad61005954d82f434d58e9','op-3','Обработка швов','over-1','p-sew-3',350,0,0,0,0,0,0,'ready',0,'["f3585367a91f6d091ae990baf9d16440"]',1,'2026-10-14 09:48:40','2026-10-14 17:42:00');
INSERT IGNORE INTO tasks (id,company_id,order_id,plan_id,operation_id,title,resource_id,worker_id,quantity,released,transferred,accepted,rework,rework_ready,scrap,state,is_final,dependencies,revision,planned_start,planned_end) VALUES ('1473a848cd6404a869ca94a8a11bc836','51d1b4be40ad979966a96944d51171fc','bdef42ac69876c643e4c323813440afc','529c13acdaad61005954d82f434d58e9','op-4','Влажно-тепловая обработка','iron-1','p-iron',350,0,0,0,0,0,0,'ready',0,'["4ad9227e7c967701205f12e4c908f990"]',1,'2026-10-14 17:42:00','2026-10-15 12:11:10');
INSERT IGNORE INTO tasks (id,company_id,order_id,plan_id,operation_id,title,resource_id,worker_id,quantity,released,transferred,accepted,rework,rework_ready,scrap,state,is_final,dependencies,revision,planned_start,planned_end) VALUES ('9c583c225ec0dc15e388113a3ce93fce','51d1b4be40ad979966a96944d51171fc','bdef42ac69876c643e4c323813440afc','529c13acdaad61005954d82f434d58e9','op-5','Контроль качества','qc-1','p-qc',350,0,0,0,0,0,0,'ready',0,'["1473a848cd6404a869ca94a8a11bc836"]',1,'2026-10-15 12:11:10','2026-10-15 15:42:00');
INSERT IGNORE INTO tasks (id,company_id,order_id,plan_id,operation_id,title,resource_id,worker_id,quantity,released,transferred,accepted,rework,rework_ready,scrap,state,is_final,dependencies,revision,planned_start,planned_end) VALUES ('6e0c5f0d9fb6e4c83e7b17a280b0da3a','51d1b4be40ad979966a96944d51171fc','bdef42ac69876c643e4c323813440afc','529c13acdaad61005954d82f434d58e9','op-6','Упаковка','pack-1','p-qc',350,0,0,0,0,0,0,'ready',1,'["9c583c225ec0dc15e388113a3ce93fce"]',1,'2026-10-15 15:42:00','2026-10-15 17:43:40');
INSERT IGNORE INTO tasks (id,company_id,order_id,plan_id,operation_id,title,resource_id,worker_id,quantity,released,transferred,accepted,rework,rework_ready,scrap,state,is_final,dependencies,revision,planned_start,planned_end) VALUES ('5982e1a549bf59af3a5a7c302442a3de','51d1b4be40ad979966a96944d51171fc','cdae4918579dc32ceed5a0d9e91a6731','529c13acdaad61005954d82f434d58e9','op-1','Раскрой деталей','cut-1','p-cut',600,600,600,0,0,0,0,'completed',0,'[]',2,'2026-10-12 16:31:10','2026-10-15 11:43:10');
INSERT IGNORE INTO tasks (id,company_id,order_id,plan_id,operation_id,title,resource_id,worker_id,quantity,released,transferred,accepted,rework,rework_ready,scrap,state,is_final,dependencies,revision,planned_start,planned_end) VALUES ('c9c74ec80b0a45b692a8e552a2c4cb59','51d1b4be40ad979966a96944d51171fc','cdae4918579dc32ceed5a0d9e91a6731','529c13acdaad61005954d82f434d58e9','op-2','Сборка изделия','sew-1','p-sew-1',600,600,600,0,0,0,0,'completed',0,'["5982e1a549bf59af3a5a7c302442a3de"]',2,'2026-10-15 11:43:10','2026-10-22 11:48:10');
INSERT IGNORE INTO tasks (id,company_id,order_id,plan_id,operation_id,title,resource_id,worker_id,quantity,released,transferred,accepted,rework,rework_ready,scrap,state,is_final,dependencies,revision,planned_start,planned_end) VALUES ('6a1008ca43c216b6bd0eecaa1c572ffa','51d1b4be40ad979966a96944d51171fc','cdae4918579dc32ceed5a0d9e91a6731','529c13acdaad61005954d82f434d58e9','op-3','Обработка швов','over-1','p-sew-3',600,600,600,0,0,0,0,'completed',0,'["c9c74ec80b0a45b692a8e552a2c4cb59"]',2,'2026-10-22 11:48:10','2026-10-27 12:53:10');
INSERT IGNORE INTO tasks (id,company_id,order_id,plan_id,operation_id,title,resource_id,worker_id,quantity,released,transferred,accepted,rework,rework_ready,scrap,state,is_final,dependencies,revision,planned_start,planned_end) VALUES ('ce86a2a98eab2191dc0a04495832ad47','51d1b4be40ad979966a96944d51171fc','cdae4918579dc32ceed5a0d9e91a6731','529c13acdaad61005954d82f434d58e9','op-4','Влажно-тепловая обработка','iron-1','p-iron',600,600,600,0,0,0,0,'completed',0,'["6a1008ca43c216b6bd0eecaa1c572ffa"]',2,'2026-10-27 12:53:10','2026-10-28 15:08:10');
INSERT IGNORE INTO tasks (id,company_id,order_id,plan_id,operation_id,title,resource_id,worker_id,quantity,released,transferred,accepted,rework,rework_ready,scrap,state,is_final,dependencies,revision,planned_start,planned_end) VALUES ('adbdc2241ed6b4b19dc8ee3dbee49e96','51d1b4be40ad979966a96944d51171fc','cdae4918579dc32ceed5a0d9e91a6731','529c13acdaad61005954d82f434d58e9','op-5','Контроль качества','qc-1','p-qc',600,600,600,0,0,0,0,'completed',0,'["ce86a2a98eab2191dc0a04495832ad47"]',2,'2026-10-28 15:08:10','2026-10-29 12:03:10');
INSERT IGNORE INTO tasks (id,company_id,order_id,plan_id,operation_id,title,resource_id,worker_id,quantity,released,transferred,accepted,rework,rework_ready,scrap,state,is_final,dependencies,revision,planned_start,planned_end) VALUES ('6491a7b8e45e076fd88f28132fbb79ee','51d1b4be40ad979966a96944d51171fc','cdae4918579dc32ceed5a0d9e91a6731','529c13acdaad61005954d82f434d58e9','op-6','Упаковка','pack-1','p-qc',600,20,20,18,2,0,0,'paused',1,'["adbdc2241ed6b4b19dc8ee3dbee49e96"]',2,'2026-10-29 12:03:10','2026-10-29 17:18:10');
INSERT IGNORE INTO tasks (id,company_id,order_id,plan_id,operation_id,title,resource_id,worker_id,quantity,released,transferred,accepted,rework,rework_ready,scrap,state,is_final,dependencies,revision,planned_start,planned_end) VALUES ('44c7b0cc25bf3fc94f6e8b490548ed5d','51d1b4be40ad979966a96944d51171fc','42ac4a2ef838b9ad0043123b3c29d80a','529c13acdaad61005954d82f434d58e9','op-1','Раскрой деталей','cut-1','p-cut',280,0,0,0,0,0,0,'ready',0,'[]',1,'2026-10-15 11:43:10','2026-10-16 14:15:10');
INSERT IGNORE INTO tasks (id,company_id,order_id,plan_id,operation_id,title,resource_id,worker_id,quantity,released,transferred,accepted,rework,rework_ready,scrap,state,is_final,dependencies,revision,planned_start,planned_end) VALUES ('34ead527d75a6215288002cc0c22dab8','51d1b4be40ad979966a96944d51171fc','42ac4a2ef838b9ad0043123b3c29d80a','529c13acdaad61005954d82f434d58e9','op-2','Сборка изделия','sew-2','p-sew-2',280,0,0,0,0,0,0,'ready',0,'["44c7b0cc25bf3fc94f6e8b490548ed5d"]',1,'2026-10-16 14:15:10','2026-10-20 17:00:10');
INSERT IGNORE INTO tasks (id,company_id,order_id,plan_id,operation_id,title,resource_id,worker_id,quantity,released,transferred,accepted,rework,rework_ready,scrap,state,is_final,dependencies,revision,planned_start,planned_end) VALUES ('769fe00755e9403d306cb138fc98ba23','51d1b4be40ad979966a96944d51171fc','42ac4a2ef838b9ad0043123b3c29d80a','529c13acdaad61005954d82f434d58e9','op-3','Обработка швов','over-1','p-sew-3',280,0,0,0,0,0,0,'ready',0,'["34ead527d75a6215288002cc0c22dab8"]',1,'2026-10-20 17:00:10','2026-10-22 11:45:10');
INSERT IGNORE INTO tasks (id,company_id,order_id,plan_id,operation_id,title,resource_id,worker_id,quantity,released,transferred,accepted,rework,rework_ready,scrap,state,is_final,dependencies,revision,planned_start,planned_end) VALUES ('60849dfa837453aa993fbdc9642ca051','51d1b4be40ad979966a96944d51171fc','42ac4a2ef838b9ad0043123b3c29d80a','529c13acdaad61005954d82f434d58e9','op-4','Влажно-тепловая обработка','iron-1','p-iron',280,0,0,0,0,0,0,'ready',0,'["769fe00755e9403d306cb138fc98ba23"]',1,'2026-10-22 11:45:10','2026-10-22 17:06:50');
INSERT IGNORE INTO tasks (id,company_id,order_id,plan_id,operation_id,title,resource_id,worker_id,quantity,released,transferred,accepted,rework,rework_ready,scrap,state,is_final,dependencies,revision,planned_start,planned_end) VALUES ('37c813492813b19e8de608768703c12f','51d1b4be40ad979966a96944d51171fc','42ac4a2ef838b9ad0043123b3c29d80a','529c13acdaad61005954d82f434d58e9','op-5','Контроль качества','qc-1','p-qc',280,0,0,0,0,0,0,'ready',0,'["60849dfa837453aa993fbdc9642ca051"]',1,'2026-10-22 17:06:50','2026-10-23 10:55:10');
INSERT IGNORE INTO tasks (id,company_id,order_id,plan_id,operation_id,title,resource_id,worker_id,quantity,released,transferred,accepted,rework,rework_ready,scrap,state,is_final,dependencies,revision,planned_start,planned_end) VALUES ('4eecb6b678c74d3e181cf3a74ab0c7d0','51d1b4be40ad979966a96944d51171fc','42ac4a2ef838b9ad0043123b3c29d80a','529c13acdaad61005954d82f434d58e9','op-6','Упаковка','pack-1','p-qc',280,0,0,0,0,0,0,'ready',1,'["37c813492813b19e8de608768703c12f"]',1,'2026-10-23 10:55:10','2026-10-23 12:56:50');
INSERT IGNORE INTO production_events (id,company_id,task_id,actor_id,kind,quantity,details) VALUES ('3822c2bbd3878253b703608cfe4b1b11','51d1b4be40ad979966a96944d51171fc','6491a7b8e45e076fd88f28132fbb79ee','3c08116887717e147b163f3c85c9f731','quality',20,'{"accepted":18,"rework":2,"scrap":0,"reason":"Учебный пример: неровная строчка","source":"Тестовые данные"}');
INSERT IGNORE INTO production_events (id,company_id,task_id,actor_id,kind,quantity,details) VALUES ('91dda0941f90aa417077d20ceb8303d0','51d1b4be40ad979966a96944d51171fc','6491a7b8e45e076fd88f28132fbb79ee','3c08116887717e147b163f3c85c9f731','pause',NULL,'{"reason":"Учебный пример: следующая партия в работе","source":"Тестовые данные"}');
INSERT IGNORE INTO economy_observations (id,company_id,order_id,actor_id,revision,accepted_quantity,recognized_cents,direct_cents,labor_cents,common_cents,source) VALUES ('5029f01a238577d95165692d59ea5e28','51d1b4be40ad979966a96944d51171fc','cdae4918579dc32ceed5a0d9e91a6731','3c08116887717e147b163f3c85c9f731',1,18,2250000,380000,700000,130000,'Учебный факт: вымышленные подтверждённые затраты 18 принятых изделий.');
INSERT IGNORE INTO audit_log (id,company_id,actor_id,action,details) VALUES ('35967c97cc7eec84ffa60b62a08c5c56','51d1b4be40ad979966a96944d51171fc','3c08116887717e147b163f3c85c9f731','plan_published','{"version":1,"source":"Тестовый контент"}');


-- Added 16 October: persisted planning decisions and resumable AI.
-- EASY3 / MySQL 5.7+: run the complete script in the existing database.
-- Existing data, tables and existing foreign keys are not removed or converted.
-- Missing optional columns of older tables are added by app/lib/schema.php.
USE `system404_easy3`;
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `plan_workspaces` (
 `id` CHAR(32) NOT NULL PRIMARY KEY,
 `company_id` CHAR(32) NOT NULL,
 `order_id` CHAR(32) NOT NULL,
 `revision` INT NOT NULL DEFAULT 1,
 `state_json` LONGTEXT NOT NULL,
 `actor_id` CHAR(32) NOT NULL,
 `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY `workspace_order` (`company_id`,`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `plan_workspace_revisions` (
 `id` CHAR(32) NOT NULL PRIMARY KEY,
 `workspace_id` CHAR(32) NOT NULL,
 `company_id` CHAR(32) NOT NULL,
 `revision` INT NOT NULL,
 `state_json` LONGTEXT NOT NULL,
 `actor_id` CHAR(32) NOT NULL,
 `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY `workspace_revision` (`workspace_id`,`revision`),
 KEY `revision_company` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- BEGIN EASY3 V6
-- EASY3 v6 / MySQL 5.7+. Additive migration; no existing data removed.

CREATE TABLE IF NOT EXISTS `ai_provider_limits` (
 `bucket` CHAR(64) NOT NULL PRIMARY KEY,
 `next_allowed` BIGINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `assistant_jobs` (
 `id` CHAR(32) NOT NULL PRIMARY KEY,
 `company_id` CHAR(32) NOT NULL,
 `actor_id` CHAR(32) NOT NULL,
 `kind` VARCHAR(30) NOT NULL,
 `request_key` VARCHAR(100) NOT NULL,
 `input_hash` CHAR(64) NOT NULL,
 `state` VARCHAR(20) NOT NULL DEFAULT 'pending',
 `input_json` LONGTEXT NOT NULL,
 `progress_json` LONGTEXT NOT NULL,
 `result_json` LONGTEXT NULL,
 `model` VARCHAR(100) NULL,
 `error_message` TEXT NULL,
 `retry_at` BIGINT NOT NULL DEFAULT 0,
 `calls` INT NOT NULL DEFAULT 0,
 `lease_token` CHAR(32) NULL,
 `lease_until` DATETIME NULL,
 `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY `assistant_command` (`company_id`,`actor_id`,`request_key`),
 KEY `assistant_actor` (`company_id`,`actor_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `document_imports` (
 `id` CHAR(32) NOT NULL PRIMARY KEY,
 `company_id` CHAR(32) NOT NULL,
 `actor_id` CHAR(32) NOT NULL,
 `display_name` VARCHAR(240) NOT NULL,
 `extension` VARCHAR(12) NOT NULL,
 `source_hash` CHAR(64) NOT NULL,
 `raw_text` MEDIUMTEXT NOT NULL,
 `safe_text` MEDIUMTEXT NOT NULL,
 `metadata_json` LONGTEXT NOT NULL,
 `state` VARCHAR(20) NOT NULL DEFAULT 'review',
 `job_id` CHAR(32) NULL,
 `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY `document_source` (`company_id`,`actor_id`,`source_hash`),
 KEY `document_actor` (`company_id`,`actor_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `document_import_applications` (
 `import_id` CHAR(32) NOT NULL,
 `candidate_index` INT NOT NULL,
 `company_id` CHAR(32) NOT NULL,
 `order_id` CHAR(32) NOT NULL,
 `actor_id` CHAR(32) NOT NULL,
 `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`import_id`,`candidate_index`),
 KEY `document_order` (`company_id`,`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

UPDATE `assistant_jobs` SET `state`='pending',`lease_token`=NULL,`lease_until`=NULL,
 `error_message`='Предыдущий запрос прерван. Продолжите сохранённое задание.'
WHERE `state`='working' AND `lease_until` IS NOT NULL AND `lease_until`<=CURRENT_TIMESTAMP;

CREATE TABLE IF NOT EXISTS `simulation_cases` (
 `id` CHAR(32) NOT NULL PRIMARY KEY,
 `company_id` CHAR(32) NOT NULL,
 `actor_id` CHAR(32) NOT NULL,
 `job_id` CHAR(32) NOT NULL,
 `variant_index` INT NOT NULL DEFAULT -1,
 `title` VARCHAR(180) NOT NULL,
 `source_hash` CHAR(64) NOT NULL,
 `settings_json` LONGTEXT NOT NULL,
 `result_json` LONGTEXT NOT NULL,
 `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY `simulation_job_variant` (`company_id`,`job_id`,`variant_index`),
 KEY `simulation_owner` (`company_id`,`actor_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
