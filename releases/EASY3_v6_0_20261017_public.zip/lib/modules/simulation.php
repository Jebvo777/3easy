<?php
declare(strict_types=1);
require_once __DIR__.'/../simulation.php';require_once __DIR__.'/../ai/simulation_prompt.php';
function simulationAction(string $action,array $input):array{
 $c=owner();
 if($action==='simulation_cases')return ['cases'=>array_map(fn($r)=>['id'=>$r['id'],'title'=>$r['title'],'created_at'=>$r['created_at'],'summary'=>decode($r['result_json'])['summary']??[]],rows('SELECT * FROM simulation_cases WHERE company_id=? AND actor_id=? ORDER BY created_at DESC LIMIT 12',[$c['id'],$_SESSION['user_id']]))];
 if($action==='simulation_case_open'){$r=one('SELECT * FROM simulation_cases WHERE id=? AND company_id=? AND actor_id=?',[textField($input,'id',32,true),$c['id'],$_SESSION['user_id']]);if(!$r)fail('Сценарий не найден',404);return ['id'=>$r['id'],'title'=>$r['title'],'result'=>decode($r['result_json'])];}
 if(in_array($action,['simulation_start','simulation_ai_start'],true)){
  $db=db();$db->beginTransaction();try{$c=context(true);$source=simulationCapture($c);if(!$source['orders'])fail('Сначала создайте хотя бы одну цель');$settings=simulationSettings($input['settings']??[],$source);$key=textField($input,'key',100,true);
   if($action==='simulation_start'){$job=workflowCreate('forecast',['source'=>$source,'settings'=>$settings],['part'=>0,'total'=>3,'stage'=>'baseline'],$key);}
   else{$intent=textField($input,'intent',4000,true);$prepared=simulationAiContext($source,$intent);$job=workflowCreate('simulation',['source'=>$source,'settings'=>$settings,'prepared'=>$prepared],['part'=>0,'total'=>6,'stage'=>'proposal','safe_intent'=>$prepared['intent']],$key);}
   $db->commit();return workflowPublic($job);
  }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
 }
 if($action==='simulation_save')return command($action,$input,function($c)use($input){$job=workflowRecord(textField($input,'id',32,true));if(!in_array($job['kind'],['forecast','simulation'],true)||$job['state']!=='ready')fail('Сначала завершите расчёт',409);$result=decode($job['result_json']);if($job['kind']==='simulation'){$index=numberField($input,'variant',0,2);$result=$result['variants'][$index]['result']??null;if(!$result)fail('Вариант ещё не рассчитан',409);}if(!$result)fail('Нет результата сценария',409);$source=simulationCapture($c);if(!hash_equals($source['source_hash'],$result['source_hash']))fail('Исходные данные изменились. Пересчитайте сценарий перед сохранением.',409);$old=one('SELECT id FROM simulation_cases WHERE company_id=? AND job_id=? AND variant_index=?',[$c['id'],$job['id'],$input['variant']??-1]);if($old)return ['id'=>$old['id'],'saved'=>true];$id=uid();query('INSERT INTO simulation_cases (id,company_id,actor_id,job_id,variant_index,title,source_hash,settings_json,result_json) VALUES (?,?,?,?,?,?,?,?,?)',[$id,$c['id'],$_SESSION['user_id'],$job['id'],$input['variant']??-1,textField($input,'title',180,true),$result['source_hash'],j($result['settings']),j($result)]);audit('simulation_saved',['id'=>$id,'job_id'=>$job['id']]);return ['id'=>$id,'saved'=>true];});
 if(!in_array($action,['simulation_step','simulation_ai_step'],true))fail('Действие симуляции не найдено',404);$id=textField($input,'id',32,true);$job=workflowRecord($id);if($job['kind']!==($action==='simulation_step'?'forecast':'simulation'))fail('Выбран другой тип задания',409);
 return workflowStep($id,function($job){$data=decode($job['input_json']);$p=decode($job['progress_json']);$source=$data['source'];$settings=$data['settings'];$result=null;$ready=false;
  if($job['kind']==='forecast'){
   if($p['part']===0){$baseSettings=simulationDefaults();$baseSettings['horizon_days']=$settings['horizon_days'];$baseSettings['scope']=$settings['scope'];$baseSettings['use_estimates']=$settings['use_estimates'];$p['baseline']=simulationCalculate($source,$baseSettings);$p['stage']='scenario';}
   elseif($p['part']===1){$p['scenario']=simulationCalculate($source,$settings);$p['stage']='result';}
   else{$result=simulationSummary($source,$p['baseline'],$p['scenario'],$settings);$ready=true;}
  }else{
   if($p['part']===0){$prepared=$data['prepared'];$r=aiGateway([],['_messages'=>simulationAiMessages($prepared,$settings),'_validator'=>fn($reply)=>simulationAiReply($reply,$source,$prepared,$settings),'_prompt_version'=>'production-scenarios-20261017.1']);$p['proposal']=$r['data'];$p['model']=$r['model'];$p['stage']='baseline';}
   elseif($p['part']===1){$b=simulationDefaults();$b['horizon_days']=$settings['horizon_days'];$b['scope']=$settings['scope'];$b['use_estimates']=$settings['use_estimates'];$p['baseline']=simulationCalculate($source,$b);$p['calculated']=[];$p['stage']='variants';}
   elseif($p['part']<=4){$index=$p['part']-2;$v=$p['proposal']['variants'][$index];$plan=simulationCalculate($source,$v['settings']);$r=simulationSummary($source,$p['baseline'],$plan,$v['settings']);$target=$p['proposal']['target'];$met=[];if($target['result_cents']!==null)$met[]=$r['summary']['period_forecast_cents']!==null&&$r['summary']['period_forecast_cents']>=$target['result_cents'];if($target['quantity']!==null)$met[]=$r['summary']['by_horizon']>=$target['quantity'];if($target['deadline']!==null)$met[]=$r['summary']['finish']!==null&&substr($r['summary']['finish'],0,10)<=$target['deadline'];$r['target_status']=$r['status']==='incomplete'||$v['new_goals']?'needs_data':(!$met?'compare':(in_array(false,$met,true)?'not_reached':'reached'));$p['calculated'][]=$v+['result'=>$r];}
   else{$result=['target'=>$p['proposal']['target'],'variants'=>$p['calculated'],'questions'=>$p['proposal']['questions'],'safe_intent'=>$data['prepared']['intent'],'source_hash'=>$source['source_hash'],'notice'=>'AI предложил изменения; сроки и результат рассчитаны программным движком. Новые цели требуют отдельного подтверждения и технологии.'];$ready=true;}
  }
  $p['part']++;return ['ready'=>$ready,'progress'=>$p,'result'=>$result,'model'=>$p['model']??null];
 });
}
